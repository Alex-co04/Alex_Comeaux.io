/**
 * Generated Pins header File
 * 
 * @file pins.h
 * 
 * @defgroup  pinsdriver Pins Driver
 * 
 * @brief This is generated driver header for pins. 
 *        This header file provides APIs for all pins selected in the GUI.
 *
 * @version Driver Version  3.1.1
*/

/*
� [2025] Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip 
    software and any derivatives exclusively with Microchip products. 
    You are responsible for complying with 3rd party license terms  
    applicable to your use of 3rd party software (including open source  
    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 
    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
    THIS SOFTWARE.
*/

#ifndef PINS_H
#define PINS_H

#include <xc.h>

#define INPUT   1
#define OUTPUT  0

#define HIGH    1
#define LOW     0

#define ANALOG      1
#define DIGITAL     0

#define PULL_UP_ENABLED      1
#define PULL_UP_DISABLED     0

// get/set RA0 aliases
#define bneg_TRIS                 TRISAbits.TRISA0
#define bneg_LAT                  LATAbits.LATA0
#define bneg_PORT                 PORTAbits.RA0
#define bneg_WPU                  WPUAbits.WPUA0
#define bneg_OD                   ODCONAbits.ODCA0
#define bneg_ANS                  ANSELAbits.ANSELA0
#define bneg_SetHigh()            do { LATAbits.LATA0 = 1; } while(0)
#define bneg_SetLow()             do { LATAbits.LATA0 = 0; } while(0)
#define bneg_Toggle()             do { LATAbits.LATA0 = ~LATAbits.LATA0; } while(0)
#define bneg_GetValue()           PORTAbits.RA0
#define bneg_SetDigitalInput()    do { TRISAbits.TRISA0 = 1; } while(0)
#define bneg_SetDigitalOutput()   do { TRISAbits.TRISA0 = 0; } while(0)
#define bneg_SetPullup()          do { WPUAbits.WPUA0 = 1; } while(0)
#define bneg_ResetPullup()        do { WPUAbits.WPUA0 = 0; } while(0)
#define bneg_SetPushPull()        do { ODCONAbits.ODCA0 = 0; } while(0)
#define bneg_SetOpenDrain()       do { ODCONAbits.ODCA0 = 1; } while(0)
#define bneg_SetAnalogMode()      do { ANSELAbits.ANSELA0 = 1; } while(0)
#define bneg_SetDigitalMode()     do { ANSELAbits.ANSELA0 = 0; } while(0)

// get/set RA1 aliases
#define apos_TRIS                 TRISAbits.TRISA1
#define apos_LAT                  LATAbits.LATA1
#define apos_PORT                 PORTAbits.RA1
#define apos_WPU                  WPUAbits.WPUA1
#define apos_OD                   ODCONAbits.ODCA1
#define apos_ANS                  ANSELAbits.ANSELA1
#define apos_SetHigh()            do { LATAbits.LATA1 = 1; } while(0)
#define apos_SetLow()             do { LATAbits.LATA1 = 0; } while(0)
#define apos_Toggle()             do { LATAbits.LATA1 = ~LATAbits.LATA1; } while(0)
#define apos_GetValue()           PORTAbits.RA1
#define apos_SetDigitalInput()    do { TRISAbits.TRISA1 = 1; } while(0)
#define apos_SetDigitalOutput()   do { TRISAbits.TRISA1 = 0; } while(0)
#define apos_SetPullup()          do { WPUAbits.WPUA1 = 1; } while(0)
#define apos_ResetPullup()        do { WPUAbits.WPUA1 = 0; } while(0)
#define apos_SetPushPull()        do { ODCONAbits.ODCA1 = 0; } while(0)
#define apos_SetOpenDrain()       do { ODCONAbits.ODCA1 = 1; } while(0)
#define apos_SetAnalogMode()      do { ANSELAbits.ANSELA1 = 1; } while(0)
#define apos_SetDigitalMode()     do { ANSELAbits.ANSELA1 = 0; } while(0)

// get/set RA2 aliases
#define bpos_TRIS                 TRISAbits.TRISA2
#define bpos_LAT                  LATAbits.LATA2
#define bpos_PORT                 PORTAbits.RA2
#define bpos_WPU                  WPUAbits.WPUA2
#define bpos_OD                   ODCONAbits.ODCA2
#define bpos_ANS                  ANSELAbits.ANSELA2
#define bpos_SetHigh()            do { LATAbits.LATA2 = 1; } while(0)
#define bpos_SetLow()             do { LATAbits.LATA2 = 0; } while(0)
#define bpos_Toggle()             do { LATAbits.LATA2 = ~LATAbits.LATA2; } while(0)
#define bpos_GetValue()           PORTAbits.RA2
#define bpos_SetDigitalInput()    do { TRISAbits.TRISA2 = 1; } while(0)
#define bpos_SetDigitalOutput()   do { TRISAbits.TRISA2 = 0; } while(0)
#define bpos_SetPullup()          do { WPUAbits.WPUA2 = 1; } while(0)
#define bpos_ResetPullup()        do { WPUAbits.WPUA2 = 0; } while(0)
#define bpos_SetPushPull()        do { ODCONAbits.ODCA2 = 0; } while(0)
#define bpos_SetOpenDrain()       do { ODCONAbits.ODCA2 = 1; } while(0)
#define bpos_SetAnalogMode()      do { ANSELAbits.ANSELA2 = 1; } while(0)
#define bpos_SetDigitalMode()     do { ANSELAbits.ANSELA2 = 0; } while(0)

// get/set RA3 aliases
#define aneg_TRIS                 TRISAbits.TRISA3
#define aneg_LAT                  LATAbits.LATA3
#define aneg_PORT                 PORTAbits.RA3
#define aneg_WPU                  WPUAbits.WPUA3
#define aneg_OD                   ODCONAbits.ODCA3
#define aneg_ANS                  ANSELAbits.ANSELA3
#define aneg_SetHigh()            do { LATAbits.LATA3 = 1; } while(0)
#define aneg_SetLow()             do { LATAbits.LATA3 = 0; } while(0)
#define aneg_Toggle()             do { LATAbits.LATA3 = ~LATAbits.LATA3; } while(0)
#define aneg_GetValue()           PORTAbits.RA3
#define aneg_SetDigitalInput()    do { TRISAbits.TRISA3 = 1; } while(0)
#define aneg_SetDigitalOutput()   do { TRISAbits.TRISA3 = 0; } while(0)
#define aneg_SetPullup()          do { WPUAbits.WPUA3 = 1; } while(0)
#define aneg_ResetPullup()        do { WPUAbits.WPUA3 = 0; } while(0)
#define aneg_SetPushPull()        do { ODCONAbits.ODCA3 = 0; } while(0)
#define aneg_SetOpenDrain()       do { ODCONAbits.ODCA3 = 1; } while(0)
#define aneg_SetAnalogMode()      do { ANSELAbits.ANSELA3 = 1; } while(0)
#define aneg_SetDigitalMode()     do { ANSELAbits.ANSELA3 = 0; } while(0)

// get/set RB0 aliases
#define IO_RB0_TRIS                 TRISBbits.TRISB0
#define IO_RB0_LAT                  LATBbits.LATB0
#define IO_RB0_PORT                 PORTBbits.RB0
#define IO_RB0_WPU                  WPUBbits.WPUB0
#define IO_RB0_OD                   ODCONBbits.ODCB0
#define IO_RB0_ANS                  ANSELBbits.ANSELB0
#define IO_RB0_SetHigh()            do { LATBbits.LATB0 = 1; } while(0)
#define IO_RB0_SetLow()             do { LATBbits.LATB0 = 0; } while(0)
#define IO_RB0_Toggle()             do { LATBbits.LATB0 = ~LATBbits.LATB0; } while(0)
#define IO_RB0_GetValue()           PORTBbits.RB0
#define IO_RB0_SetDigitalInput()    do { TRISBbits.TRISB0 = 1; } while(0)
#define IO_RB0_SetDigitalOutput()   do { TRISBbits.TRISB0 = 0; } while(0)
#define IO_RB0_SetPullup()          do { WPUBbits.WPUB0 = 1; } while(0)
#define IO_RB0_ResetPullup()        do { WPUBbits.WPUB0 = 0; } while(0)
#define IO_RB0_SetPushPull()        do { ODCONBbits.ODCB0 = 0; } while(0)
#define IO_RB0_SetOpenDrain()       do { ODCONBbits.ODCB0 = 1; } while(0)
#define IO_RB0_SetAnalogMode()      do { ANSELBbits.ANSELB0 = 1; } while(0)
#define IO_RB0_SetDigitalMode()     do { ANSELBbits.ANSELB0 = 0; } while(0)

// get/set RB1 aliases
#define IO_RB1_TRIS                 TRISBbits.TRISB1
#define IO_RB1_LAT                  LATBbits.LATB1
#define IO_RB1_PORT                 PORTBbits.RB1
#define IO_RB1_WPU                  WPUBbits.WPUB1
#define IO_RB1_OD                   ODCONBbits.ODCB1
#define IO_RB1_ANS                  ANSELBbits.ANSELB1
#define IO_RB1_SetHigh()            do { LATBbits.LATB1 = 1; } while(0)
#define IO_RB1_SetLow()             do { LATBbits.LATB1 = 0; } while(0)
#define IO_RB1_Toggle()             do { LATBbits.LATB1 = ~LATBbits.LATB1; } while(0)
#define IO_RB1_GetValue()           PORTBbits.RB1
#define IO_RB1_SetDigitalInput()    do { TRISBbits.TRISB1 = 1; } while(0)
#define IO_RB1_SetDigitalOutput()   do { TRISBbits.TRISB1 = 0; } while(0)
#define IO_RB1_SetPullup()          do { WPUBbits.WPUB1 = 1; } while(0)
#define IO_RB1_ResetPullup()        do { WPUBbits.WPUB1 = 0; } while(0)
#define IO_RB1_SetPushPull()        do { ODCONBbits.ODCB1 = 0; } while(0)
#define IO_RB1_SetOpenDrain()       do { ODCONBbits.ODCB1 = 1; } while(0)
#define IO_RB1_SetAnalogMode()      do { ANSELBbits.ANSELB1 = 1; } while(0)
#define IO_RB1_SetDigitalMode()     do { ANSELBbits.ANSELB1 = 0; } while(0)

// get/set RB2 aliases
#define IO_RB2_TRIS                 TRISBbits.TRISB2
#define IO_RB2_LAT                  LATBbits.LATB2
#define IO_RB2_PORT                 PORTBbits.RB2
#define IO_RB2_WPU                  WPUBbits.WPUB2
#define IO_RB2_OD                   ODCONBbits.ODCB2
#define IO_RB2_ANS                  ANSELBbits.ANSELB2
#define IO_RB2_SetHigh()            do { LATBbits.LATB2 = 1; } while(0)
#define IO_RB2_SetLow()             do { LATBbits.LATB2 = 0; } while(0)
#define IO_RB2_Toggle()             do { LATBbits.LATB2 = ~LATBbits.LATB2; } while(0)
#define IO_RB2_GetValue()           PORTBbits.RB2
#define IO_RB2_SetDigitalInput()    do { TRISBbits.TRISB2 = 1; } while(0)
#define IO_RB2_SetDigitalOutput()   do { TRISBbits.TRISB2 = 0; } while(0)
#define IO_RB2_SetPullup()          do { WPUBbits.WPUB2 = 1; } while(0)
#define IO_RB2_ResetPullup()        do { WPUBbits.WPUB2 = 0; } while(0)
#define IO_RB2_SetPushPull()        do { ODCONBbits.ODCB2 = 0; } while(0)
#define IO_RB2_SetOpenDrain()       do { ODCONBbits.ODCB2 = 1; } while(0)
#define IO_RB2_SetAnalogMode()      do { ANSELBbits.ANSELB2 = 1; } while(0)
#define IO_RB2_SetDigitalMode()     do { ANSELBbits.ANSELB2 = 0; } while(0)

// get/set RB3 aliases
#define IO_RB3_TRIS                 TRISBbits.TRISB3
#define IO_RB3_LAT                  LATBbits.LATB3
#define IO_RB3_PORT                 PORTBbits.RB3
#define IO_RB3_WPU                  WPUBbits.WPUB3
#define IO_RB3_OD                   ODCONBbits.ODCB3
#define IO_RB3_ANS                  ANSELBbits.ANSELB3
#define IO_RB3_SetHigh()            do { LATBbits.LATB3 = 1; } while(0)
#define IO_RB3_SetLow()             do { LATBbits.LATB3 = 0; } while(0)
#define IO_RB3_Toggle()             do { LATBbits.LATB3 = ~LATBbits.LATB3; } while(0)
#define IO_RB3_GetValue()           PORTBbits.RB3
#define IO_RB3_SetDigitalInput()    do { TRISBbits.TRISB3 = 1; } while(0)
#define IO_RB3_SetDigitalOutput()   do { TRISBbits.TRISB3 = 0; } while(0)
#define IO_RB3_SetPullup()          do { WPUBbits.WPUB3 = 1; } while(0)
#define IO_RB3_ResetPullup()        do { WPUBbits.WPUB3 = 0; } while(0)
#define IO_RB3_SetPushPull()        do { ODCONBbits.ODCB3 = 0; } while(0)
#define IO_RB3_SetOpenDrain()       do { ODCONBbits.ODCB3 = 1; } while(0)
#define IO_RB3_SetAnalogMode()      do { ANSELBbits.ANSELB3 = 1; } while(0)
#define IO_RB3_SetDigitalMode()     do { ANSELBbits.ANSELB3 = 0; } while(0)

// get/set RB4 aliases
#define IO_RB4_TRIS                 TRISBbits.TRISB4
#define IO_RB4_LAT                  LATBbits.LATB4
#define IO_RB4_PORT                 PORTBbits.RB4
#define IO_RB4_WPU                  WPUBbits.WPUB4
#define IO_RB4_OD                   ODCONBbits.ODCB4
#define IO_RB4_ANS                  ANSELBbits.ANSELB4
#define IO_RB4_SetHigh()            do { LATBbits.LATB4 = 1; } while(0)
#define IO_RB4_SetLow()             do { LATBbits.LATB4 = 0; } while(0)
#define IO_RB4_Toggle()             do { LATBbits.LATB4 = ~LATBbits.LATB4; } while(0)
#define IO_RB4_GetValue()           PORTBbits.RB4
#define IO_RB4_SetDigitalInput()    do { TRISBbits.TRISB4 = 1; } while(0)
#define IO_RB4_SetDigitalOutput()   do { TRISBbits.TRISB4 = 0; } while(0)
#define IO_RB4_SetPullup()          do { WPUBbits.WPUB4 = 1; } while(0)
#define IO_RB4_ResetPullup()        do { WPUBbits.WPUB4 = 0; } while(0)
#define IO_RB4_SetPushPull()        do { ODCONBbits.ODCB4 = 0; } while(0)
#define IO_RB4_SetOpenDrain()       do { ODCONBbits.ODCB4 = 1; } while(0)
#define IO_RB4_SetAnalogMode()      do { ANSELBbits.ANSELB4 = 1; } while(0)
#define IO_RB4_SetDigitalMode()     do { ANSELBbits.ANSELB4 = 0; } while(0)

// get/set RB5 aliases
#define IO_RB5_TRIS                 TRISBbits.TRISB5
#define IO_RB5_LAT                  LATBbits.LATB5
#define IO_RB5_PORT                 PORTBbits.RB5
#define IO_RB5_WPU                  WPUBbits.WPUB5
#define IO_RB5_OD                   ODCONBbits.ODCB5
#define IO_RB5_ANS                  ANSELBbits.ANSELB5
#define IO_RB5_SetHigh()            do { LATBbits.LATB5 = 1; } while(0)
#define IO_RB5_SetLow()             do { LATBbits.LATB5 = 0; } while(0)
#define IO_RB5_Toggle()             do { LATBbits.LATB5 = ~LATBbits.LATB5; } while(0)
#define IO_RB5_GetValue()           PORTBbits.RB5
#define IO_RB5_SetDigitalInput()    do { TRISBbits.TRISB5 = 1; } while(0)
#define IO_RB5_SetDigitalOutput()   do { TRISBbits.TRISB5 = 0; } while(0)
#define IO_RB5_SetPullup()          do { WPUBbits.WPUB5 = 1; } while(0)
#define IO_RB5_ResetPullup()        do { WPUBbits.WPUB5 = 0; } while(0)
#define IO_RB5_SetPushPull()        do { ODCONBbits.ODCB5 = 0; } while(0)
#define IO_RB5_SetOpenDrain()       do { ODCONBbits.ODCB5 = 1; } while(0)
#define IO_RB5_SetAnalogMode()      do { ANSELBbits.ANSELB5 = 1; } while(0)
#define IO_RB5_SetDigitalMode()     do { ANSELBbits.ANSELB5 = 0; } while(0)

// get/set RC1 aliases
#define LED3_TRIS                 TRISCbits.TRISC1
#define LED3_LAT                  LATCbits.LATC1
#define LED3_PORT                 PORTCbits.RC1
#define LED3_WPU                  WPUCbits.WPUC1
#define LED3_OD                   ODCONCbits.ODCC1
#define LED3_ANS                  ANSELCbits.ANSELC1
#define LED3_SetHigh()            do { LATCbits.LATC1 = 1; } while(0)
#define LED3_SetLow()             do { LATCbits.LATC1 = 0; } while(0)
#define LED3_Toggle()             do { LATCbits.LATC1 = ~LATCbits.LATC1; } while(0)
#define LED3_GetValue()           PORTCbits.RC1
#define LED3_SetDigitalInput()    do { TRISCbits.TRISC1 = 1; } while(0)
#define LED3_SetDigitalOutput()   do { TRISCbits.TRISC1 = 0; } while(0)
#define LED3_SetPullup()          do { WPUCbits.WPUC1 = 1; } while(0)
#define LED3_ResetPullup()        do { WPUCbits.WPUC1 = 0; } while(0)
#define LED3_SetPushPull()        do { ODCONCbits.ODCC1 = 0; } while(0)
#define LED3_SetOpenDrain()       do { ODCONCbits.ODCC1 = 1; } while(0)
#define LED3_SetAnalogMode()      do { ANSELCbits.ANSELC1 = 1; } while(0)
#define LED3_SetDigitalMode()     do { ANSELCbits.ANSELC1 = 0; } while(0)

// get/set RD5 aliases
#define IO_RD5_TRIS                 TRISDbits.TRISD5
#define IO_RD5_LAT                  LATDbits.LATD5
#define IO_RD5_PORT                 PORTDbits.RD5
#define IO_RD5_WPU                  WPUDbits.WPUD5
#define IO_RD5_OD                   ODCONDbits.ODCD5
#define IO_RD5_ANS                  ANSELDbits.ANSELD5
#define IO_RD5_SetHigh()            do { LATDbits.LATD5 = 1; } while(0)
#define IO_RD5_SetLow()             do { LATDbits.LATD5 = 0; } while(0)
#define IO_RD5_Toggle()             do { LATDbits.LATD5 = ~LATDbits.LATD5; } while(0)
#define IO_RD5_GetValue()           PORTDbits.RD5
#define IO_RD5_SetDigitalInput()    do { TRISDbits.TRISD5 = 1; } while(0)
#define IO_RD5_SetDigitalOutput()   do { TRISDbits.TRISD5 = 0; } while(0)
#define IO_RD5_SetPullup()          do { WPUDbits.WPUD5 = 1; } while(0)
#define IO_RD5_ResetPullup()        do { WPUDbits.WPUD5 = 0; } while(0)
#define IO_RD5_SetPushPull()        do { ODCONDbits.ODCD5 = 0; } while(0)
#define IO_RD5_SetOpenDrain()       do { ODCONDbits.ODCD5 = 1; } while(0)
#define IO_RD5_SetAnalogMode()      do { ANSELDbits.ANSELD5 = 1; } while(0)
#define IO_RD5_SetDigitalMode()     do { ANSELDbits.ANSELD5 = 0; } while(0)

/**
 * @ingroup  pinsdriver
 * @brief GPIO and peripheral I/O initialization
 * @param none
 * @return none
 */
void PIN_MANAGER_Initialize (void);

/**
 * @ingroup  pinsdriver
 * @brief Interrupt on Change Handling routine
 * @param none
 * @return none
 */
void PIN_MANAGER_IOC(void);


#endif // PINS_H
/**
 End of File
*/